คู่มือเผยแพร่ Web App แผนกช่าง CIT

ไฟล์นี้เป็นเว็บแบบ Static + PWA และเชื่อมไปยัง Google Forms / Google Drive ตามลิงก์ที่ได้รับ
ยังไม่ใช่ URL ที่เผยแพร่แล้ว และ QR Code สุดท้ายต้องสร้างหลังได้ URL จริง

วิธีเผยแพร่แบบฟรีด้วย GitHub Pages
1. สมัคร/เข้าสู่ระบบ https://github.com
2. สร้าง Repository ใหม่ เช่น cit-technician-portal
3. เลือก Public และสร้าง Repository
4. อัปโหลดไฟล์และโฟลเดอร์ทั้งหมดใน ZIP นี้ (ต้องอัปโหลดไฟล์ index.html ไว้ระดับบนสุด)
5. ไปที่ Settings > Pages
6. ใน Build and deployment เลือก Deploy from a branch
7. เลือก Branch: main และ Folder: /(root) แล้วกด Save
8. รอ GitHub แสดง URL เว็บไซต์ เช่น https://ชื่อบัญชี.github.io/cit-technician-portal/

การใช้งานบนโทรศัพท์
- Android: เปิด URL ด้วย Chrome > เมนู ⋮ > Install app หรือ Add to Home screen
- iPhone: เปิด URL ด้วย Safari > Share > Add to Home Screen

QR Code
หลังเผยแพร่แล้ว ให้ใช้ URL เว็บไซต์จริงสร้าง QR Code (อย่าใช้ URL ของ Repository)
สามารถส่ง URL ที่ GitHub Pages สร้างให้กลับมา แล้วจึงจัดทำ QR Code สำหรับพิมพ์ได้

โลโก้
ขณะนี้ใช้ตัวอักษร CIT เป็นโลโก้ชั่วคราว เพราะยังไม่มีไฟล์โลโก้จริง
เมื่อมีโลโก้ PNG/SVG ให้เปลี่ยนส่วน .brand-mark ใน index.html เป็นรูปภาพ และปรับขนาดใน style.css

ตรวจสิทธิ์ Google
- โฟลเดอร์ Drive ทั้งสองรายการต้องแชร์ให้ผู้ใช้งานเป้าหมายมีสิทธิ์ Viewer
- Forms ต้องตั้งค่าให้ผู้ตอบที่ต้องการสามารถเปิดและส่งคำตอบได้
- หากฟอร์มจำกัดเฉพาะบัญชีองค์กร ผู้ใช้ Gmail ภายนอกอาจเข้าไม่ได้
- ลิงก์ PM ใช้ viewform?usp=sharing แล้ว แต่ต้องทดสอบส่งคำตอบจริงก่อนเปิดใช้งาน

หมายเหตุ PWA
การติดตั้งเป็นไอคอนและแคชหน้าเมนูต้องเผยแพร่ผ่าน HTTPS (GitHub Pages ให้ HTTPS)
เอกสาร Google Forms/Drive จะต้องใช้อินเทอร์เน็ตและขึ้นกับสิทธิ์ของ Google
